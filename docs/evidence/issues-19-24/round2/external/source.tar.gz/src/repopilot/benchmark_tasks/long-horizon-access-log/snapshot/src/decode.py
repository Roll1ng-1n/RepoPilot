def decode(data):
    return []
